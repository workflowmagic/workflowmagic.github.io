---
name: Feature request
about: Suggest an idea for this project
title: ''
labels: ''
assignees: ''

---

<!--
Thanks for taking the time to suggest an improvement!
It's appreciated as it helps me understand how KeyboardJS is being used and how I can make it better for all of us. Cheers! 🍻
-->

**What would you like to see added to KeyboardJS?**
<!-- Describe your idea here. Explain how KeyboardJS would change. Code examples are very helpful if you can provide them. -->

**What problem are you trying to solve?**
<!-- Describe why you think this would be a useful addition to the library. Again, code examples are very helpful if you can provide them. -->

**Additional comments**
<!-- Anything else you'd like to add. -->
