import sinon from 'sinon';


export const document = {
  addEventListener: sinon.stub(),
  removeEventListener: sinon.stub(),
};
